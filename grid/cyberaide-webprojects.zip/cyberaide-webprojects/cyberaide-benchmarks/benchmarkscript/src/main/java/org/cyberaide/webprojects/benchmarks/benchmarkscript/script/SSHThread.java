/**
 * SSHThread.java
 * 
 * Version:
 * $Id: SSHThread.java,v 1.4 2008/05/03 05:18:04 bisrael Exp $
 * 
 * Revisions:
 * $Log: SSHThread.java,v $
 * Revision 1.4  2008/05/03 05:18:04  bisrael
 * Fixed so that it doesn't send grid information to web service if ssh connection error occurred.
 * Other minor fixes.
 * Commented out debugging output.
 *
 * Revision 1.3  2008/05/01 22:51:55  bisrael
 * Uses thread pools to start only a certain number of ssh threads, and
 * waits for all threads to finish before continuing.
 * Changed to use synchronized storage container for ssh thread data.
 * Now sends compiled xml data to web service.
 * Gets all grid data from config file.
 *
 * Revision 1.2  2008/04/30 21:48:47  bisrael
 * *** empty log message ***
 *
 * Revision 1.1  2008/04/30 19:41:02  bisrael
 * Eclipse project for modifying/testing the client before it gets put into the maven project.
 *
 * Revision 1.2  2008/04/22 19:37:41  jludwig
 * bisrael - changed to get more information from configuration file.
 *
 * Revision 1.1  2008/04/22 10:05:10  bisrael
 * Updated the originaly benchmark script to be a web service client and send data to the benchmark web script.
 *
 * Revision 1.1  2008/04/19 07:00:31  bisrael
 * Initial test script that reads in remote hosts from an XML config file, connects to the hosts over SSH, gathers information, and runs benchmarks.
 *
 *
 */
package org.cyberaide.webprojects.benchmarks.benchmarkscript.script;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import com.trilead.ssh2.Connection;
import com.trilead.ssh2.Session;
import com.trilead.ssh2.StreamGobbler;

/**
 * Thread that connects to a hosts SSH server and
 * runs the benchmarks.
 *
 * @author Brad Israel - bdi8241@cs.rit.edu
 *
 */
public class SSHThread extends Thread {

	/*
	 * Remote hostname
	 */
	private String hostname;
	
	/*
	 * Remote username
	 */
	private String username;
	
	/*
	 * Private key file, used when
	 * public key is on all the hosts.
	 */
	private File SSHKey = null;
	
	/*
	 * Remote password, entered from console.
	 */
	private String password;
	
	/*
	 * List of benchmarks to run
	 */
	private String[] benchmarks;
	
	/*
	 * Used to compile the system xml data
	 */
	private StringBuffer systemXml;
	
	/*
	 * Name of the cluster
	 */
	private String clusterName;
	
	/*
	 * Synchronized class for thread to dump their
	 * system xml data.
	 */
	private GridXMLCreator xmlData;
	
	/*
	 * XML configuration reader instance
	 */
	private ConfigurationReader config = ConfigurationReader.getInstance();

	/**
	 * Thread Constructor.
	 * 
	 * @param hostname - remote host to connect to
	 * @param username - remote username
	 * @param SSHKey - local private ssh key
	 * @param password - remote/key password
	 * @param clusterName - cluster name
	 * @param xmlData - synchronized class for storing system xml data
	 */
	public SSHThread(String hostname, String username, File SSHKey, String password, 
			String clusterName, GridXMLCreator xmlData){
		this.hostname = hostname;
		this.username = username;
		this.SSHKey = SSHKey;
		this.password = password;
		this.clusterName = clusterName;
		this.xmlData = xmlData;
		this.systemXml = new StringBuffer();
		this.benchmarks = config.getBenchmarks();
	}

	/**
	 * Start the thread.
	 * 
	 * Connects to the remote host, authenticates with information
	 * from the config file, gather name, proc, disk, and memory information,
	 * copies the benchmarks to the host, run the benchmarks and get the
	 * standard output.
	 */
	public void run() {
		ArrayList<String> hostData = null;
		String simpleHostname = null;
		
		//For debugging only
		System.out.println("Connecting to " + hostname);
		
		try{
			hostData = new ArrayList<String>();
			
			//Create new connection to host
			Connection conn = new Connection(hostname);
			conn.connect();
			
			//Authenticate
			//If a ssh key was specified, use public key method
			//Else use password method
			boolean isAuthenticated = false;
			if(SSHKey != null){
				isAuthenticated = conn.authenticateWithPublicKey(username, SSHKey, password);
				if(!isAuthenticated){
					throw new IOException("Authentication failed.");
				}
			}else{
				isAuthenticated = conn.authenticateWithPassword(username, password);
				if(!isAuthenticated){
					throw new IOException("Authentication failed.");
				}
			}
			
			//Default session name
			Session sess = null;
			
			//Basic system info for unix only,
			//this will be updated for all systems.
			systemXml.append("<System>");
			
			sess = conn.openSession();
			sess.execCommand("uname -n");
			simpleHostname = readStdOutFromServer(sess);
			systemXml.append("<Hostname>" + simpleHostname + "</Hostname>");
			sess.close();
			
			sess = conn.openSession();
			sess.execCommand("uname -o");
			systemXml.append("<OS>" + readStdOutFromServer(sess) + "</OS>");
			sess.close();
			
			sess = conn.openSession();
			sess.execCommand("uname -r");
			systemXml.append("<Kernel>" + readStdOutFromServer(sess) + "</Kernel>");
			sess.close();
			
			sess = conn.openSession();
			sess.execCommand("uname -p");
			systemXml.append("<CPU>" + readStdOutFromServer(sess) + "</CPU>");
			sess.close();
			
			//TODO: Fix to only get total system memory
			sess = conn.openSession();
			sess.execCommand("cat /proc/meminfo |grep MemTotal");
			systemXml.append("<TotalMem>" + readStdOutFromServer(sess) + "</TotalMem>");
			sess.close();
			
			//TODO: Get total disk space from system
//			sess = conn.openSession();
//			sess.execCommand("");
			systemXml.append("<TotalDisk>GB</TotalDisk>");
//			sess.close();
			
			//TODO: Run each benchmark and parse the response
			//Make Benchmarks directory
//			sess = conn.openSession();
//			sess.execCommand("mkdir Benchmarks");
//			sess.close();
//			
//			//SCP benchmarks to the remote host
//			sess = conn.openSession();
//			SCPClient scp = conn.createSCPClient();
//			scp.put(benchmarks, "Benchmarks", "0755");
//			sess.close();
//			
//			//Run the benchmark and read the results
//			for(String bench : benchmarks){
//				sess = conn.openSession();
//				sess.execCommand(bench);
//				readStdOutFromServer(sess);
//				sess.close();
//			}
//			
//			//Cleanup the benchmarks
//			sess = conn.openSession();
//			sess.execCommand("rm -Rf Benchmarks");
//			sess.close();
			
			//Close the connection to host
			conn.close();
			
			systemXml.append("</System>");
			
			//Add xml data to synchronized class
			xmlData.addSystemInfo(clusterName, simpleHostname, systemXml.toString());
			
		}catch(IOException ioe){
			System.out.println("Couldn't connect to " + hostname + "\n" +
					"Reason: " + ioe.getMessage());
			
			//Tell main class that error occurred
			xmlData.sshThreadErrorOccurred();
//			ioe.printStackTrace();
		}
	}

	/**
	 * Read the standard out from the remote host.
	 * Output to local file in the correct format.
	 * 
	 * @param sess - SSH session to read from
	 */
	private String readStdOutFromServer(Session sess){
		String retVal = null;
		try{
			InputStream stdout = new StreamGobbler(sess.getStdout());
			BufferedReader br = new BufferedReader(new InputStreamReader(stdout));

			while (true){
				String line = br.readLine();
				if (line == null)
					break;
				retVal = line;
			}
		}catch(IOException ioe){
			System.out.println("Failed to read stdout from server");
		}
		return retVal;
	}

}
