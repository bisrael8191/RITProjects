/**
 * RunBenchmark.java
 * 
 * Version:
 * $Id: RunBenchmark.java,v 1.3 2008/05/01 22:51:55 bisrael Exp $
 * 
 * Revisions:
 * $Log: RunBenchmark.java,v $
 * Revision 1.3  2008/05/01 22:51:55  bisrael
 * Uses thread pools to start only a certain number of ssh threads, and
 * waits for all threads to finish before continuing.
 * Changed to use synchronized storage container for ssh thread data.
 * Now sends compiled xml data to web service.
 * Gets all grid data from config file.
 *
 * Revision 1.2  2008/04/30 21:47:05  bisrael
 * Testing for configuration reader.
 *
 * Revision 1.1  2008/04/30 19:41:02  bisrael
 * Eclipse project for modifying/testing the client before it gets put into the maven project.
 *
 * Revision 1.1  2008/04/22 10:05:07  bisrael
 * Updated the originaly benchmark script to be a web service client and send data to the benchmark web script.
 *
 * Revision 1.1  2008/04/19 07:00:31  bisrael
 * Initial test script that reads in remote hosts from an XML config file, connects to the hosts over SSH, gathers information, and runs benchmarks.
 *
 *
 */
package org.cyberaide.webprojects.benchmarks.benchmarkscript;

import org.cyberaide.webprojects.benchmarks.benchmarkscript.script.ConfigurationReader;
import org.cyberaide.webprojects.benchmarks.benchmarkscript.script.SSHToHosts;

/**
 * Main file to run the benchmark scripts on the systems
 * specified in the configuration file.
 *
 * @author Brad Israel - bdi8241@cs.rit.edu
 *
 */
public class RunBenchmark {

	/**
	 * Do any initial processing and start spawning 
	 * SSH threads.
	 * 
	 * @param args - Will eventually be a list of config files
	 */
	public static void main(String[] args) {
		SSHToHosts script = new SSHToHosts();
		script.startScript();
	}

}
