/**
 * GridXMLCreator.java
 * 
 * Version:
 * $Id: GridXMLCreator.java,v 1.3 2008/05/06 07:20:09 bisrael Exp $
 * 
 * Revisions:
 * $Log: GridXMLCreator.java,v $
 * Revision 1.3  2008/05/06 07:20:09  bisrael
 * Changed to produce proper xml output.
 * Now sends grid name to web service (will be used to check if the grid already exists).
 *
 * Revision 1.2  2008/05/03 05:18:04  bisrael
 * Fixed so that it doesn't send grid information to web service if ssh connection error occurred.
 * Other minor fixes.
 * Commented out debugging output.
 *
 * Revision 1.1  2008/05/01 22:51:55  bisrael
 * Uses thread pools to start only a certain number of ssh threads, and
 * waits for all threads to finish before continuing.
 * Changed to use synchronized storage container for ssh thread data.
 * Now sends compiled xml data to web service.
 * Gets all grid data from config file.
 *
 */
package org.cyberaide.webprojects.benchmarks.benchmarkscript.script;

import java.util.Map;
import java.util.TreeMap;

/**
 * Synchronized class that gets xml information from the SSH
 * threads, then can be called by the main class to get the
 * final XML to send to the web service.
 *
 * @author Brad Israel - bdi8241@cs.rit.edu
 *
 */
public class GridXMLCreator {

	/*
	 * Hold cluster and system information,
	 * uses a TreeMap so it's will list both in
	 * sorted order by cluster, then hostname.
	 */
	private Map<String, Map<String, String>> clusters;

	private boolean errorOccurred = false;

	/**
	 * Default constructor
	 */
	public GridXMLCreator(){
		clusters = new TreeMap<String, Map<String, String>>();
	}

	/**
	 * Add a new system to the cluster.
	 * Used by the SSHThread class, so it has to be sychronized.
	 * 
	 * @param clusterName - Name of the cluster that the system is in
	 * @param hostname - Name of the computer
	 * @param xmlData - System information and benchmark times (XML format)
	 */
	public synchronized void addSystemInfo(String clusterName, String hostname, String xmlData){
		//Create the cluster if it didn't previously exist
		if(!clusters.containsKey(clusterName)){
			clusters.put(clusterName, new TreeMap<String, String>());
		}

		//Add the system information to the cluster
		Map<String, String> systemList = clusters.get(clusterName);
		systemList.put(hostname, xmlData);
	}

	/**
	 * Allows the ssh threads to tell the main class that
	 * they couldn't connect to a host. The host information
	 * and reason will be outputted to the console.
	 */
	public synchronized void sshThreadErrorOccurred(){
		errorOccurred = true;
	}

	/**
	 * Allows the main class to check if an ssh connection error
	 * occurred.
	 * 
	 * @return true if an error occurred, false if everything succeeded
	 */
	public boolean didErrorOccur(){
		return errorOccurred;
	}

	/**
	 * Returns the compiled xml file to send to the web service.
	 * This is only called after all the SSH threads have finished
	 * running.
	 * All parameters are set in the configuration.xml file.
	 * 
	 * @param gridName - Name of the grid
	 * @param contactName - Grid administrator name
	 * @param contactPhone - Grid phone number
	 * @param location - Grid location
	 * @return Final XML file
	 */
	public String getFinalXml(String gridName, String contactName, String contactPhone, String location){
		StringBuffer retVal = new StringBuffer();

		//Create the xml file for the grid,
		//will appear all on one line for the server.
//		retVal.append("<Grid>");
		retVal.append("<GridInfo>");
		retVal.append("<GridName>" + gridName + "</GridName>");
		retVal.append("<ContactName>" + contactName + "</ContactName>");
		retVal.append("<ContactPhone>" + contactPhone + "</ContactPhone>");
		retVal.append("<Location>" + location + "</Location>");
		retVal.append("</GridInfo>");
		retVal.append("<GridBenchmarks>");

		//Grid benchmarks go here

		retVal.append("</GridBenchmarks>");

		retVal.append("<Clusters>");

		//Loop through the clusters and their systems
		//to add their xml data
		for(String clusterName : clusters.keySet()){
			retVal.append("<Cluster>");
			retVal.append("<ClusterName>" + clusterName + "</ClusterName>");

			retVal.append("<Systems>");
			Map<String, String> systemList = clusters.get(clusterName);
			for(Object systemName : systemList.keySet()){
				if(systemName instanceof String){
					retVal.append(systemList.get(systemName));
				}
			}
			retVal.append("</Systems>");

			retVal.append("</Cluster>");
		}

		retVal.append("</Clusters>");

//		retVal.append("</Grid>\n");

		return retVal.toString();
	}
}
