/**
 * WSClient.java
 * 
 * Version:
 * $Id: WSClient.java,v 1.4 2008/05/06 07:20:09 bisrael Exp $
 * 
 * Revisions:
 * $Log: WSClient.java,v $
 * Revision 1.4  2008/05/06 07:20:09  bisrael
 * Changed to produce proper xml output.
 * Now sends grid name to web service (will be used to check if the grid already exists).
 *
 * Revision 1.3  2008/05/03 05:18:04  bisrael
 * Fixed so that it doesn't send grid information to web service if ssh connection error occurred.
 * Other minor fixes.
 * Commented out debugging output.
 *
 * Revision 1.2  2008/05/01 22:51:55  bisrael
 * Uses thread pools to start only a certain number of ssh threads, and
 * waits for all threads to finish before continuing.
 * Changed to use synchronized storage container for ssh thread data.
 * Now sends compiled xml data to web service.
 * Gets all grid data from config file.
 *
 * Revision 1.1  2008/04/30 19:41:02  bisrael
 * Eclipse project for modifying/testing the client before it gets put into the maven project.
 *
 * Revision 1.2  2008/04/22 19:37:41  jludwig
 * bisrael - changed to get more information from configuration file.
 *
 * Revision 1.1  2008/04/22 10:05:10  bisrael
 * Updated the originaly benchmark script to be a web service client and send data to the benchmark web script.
 *
 *
 */
package org.cyberaide.webprojects.benchmarks.benchmarkscript.script;

import java.util.ArrayList;

import javax.xml.namespace.QName;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMFactory;
import org.apache.axiom.om.OMNamespace;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.Options;
import org.apache.axis2.client.ServiceClient;

/**
 * Class to connect to the web service and
 * send the needed data.
 *
 * @author Brad Israel - bdi8241@cs.rit.edu
 *
 */
public class WSClient {
	
	/*
	 * Web service target address
	 */
	private String wsTarget = null;
	
	/*
	 * Axis web service client class
	 */
	private ServiceClient client = null;
	
	/**
	 * Default constructor.
	 * 
	 * @param wsTarget - web service target address
	 */
	public WSClient(String wsTarget){
		this.wsTarget = wsTarget;
	}
	
	/**
	 * Send data (XML file) to the web service,
	 * uses the grid name as the reference.
	 * 
	 * @param data - Compiled XML file for the grid
	 * @return web service return string
	 */
	public String sendData(String gridName, String data){
		String retVal = null;
		OMElement rec = null;
		try{
			//Create new ws client
			client = new ServiceClient();
	        // create option object
	        Options opts = new Options();
	        //setting target EPR
	        opts.setTo(new EndpointReference(wsTarget));
	        //Setting action which can be found from the wsdl of the service
	        //Read/Discover? or statically set?
	        opts.setAction("urn:collect");
	        client.setOptions(opts);
			rec = client.sendReceive(createPayLoad(gridName, data));
		}catch(Exception e){
//			e.printStackTrace();
		}
		
		//TODO:FIX, get return attribute value
		if(!rec.equals(null)){
			retVal =  "success";/*rec.getAttributeValue(new QName("ns:return"));*/
		}
		return retVal;
	}
	
	/**
	 * Create XML payload, used to send soap data to web service.
	 * 
	 * @param data - Grid XML data
	 * @return OM payload
	 */
	private OMElement createPayLoad(String gridName, String data) {
		OMFactory fac = OMAbstractFactory.getOMFactory();
        OMNamespace omNs = fac.createOMNamespace("http://benchmarkws.benchmarks.webprojects.cyberaide.org", "ns0");
        OMElement method = fac.createOMElement("collect", omNs);
        
        OMElement gName = fac.createOMElement("gridName", omNs);
        gName.setText(gridName.toString());
        method.addChild(gName);
        
        OMElement clientXml = fac.createOMElement("clientXml", omNs);
        clientXml.setText(data.toString());
        method.addChild(clientXml);
        
        return method;
	}

}
