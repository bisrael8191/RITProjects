package org.cyberaide.webprojects.benchmarks.benchmarkscript.script;

public class CopyLock {
	
	boolean value;
	
	public CopyLock(boolean val) {
		value = val;
	}
	
	public void set() {
		value = true;
	}
	
	public void clear() {
		value = false;
	}
	
	public boolean get() {
		return value;
	}

}
