/**
 * SSHToHosts.java
 * 
 * Version:
 * $Id: SSHToHosts.java,v 1.8 2008/05/06 07:20:09 bisrael Exp $
 * 
 * Revisions:
 * $Log: SSHToHosts.java,v $
 * Revision 1.8  2008/05/06 07:20:09  bisrael
 * Changed to produce proper xml output.
 * Now sends grid name to web service (will be used to check if the grid already exists).
 *
 * Revision 1.7  2008/05/03 05:18:04  bisrael
 * Fixed so that it doesn't send grid information to web service if ssh connection error occurred.
 * Other minor fixes.
 * Commented out debugging output.
 *
 * Revision 1.6  2008/05/03 04:46:04  bisrael
 * Added console imports.
 *
 * Revision 1.5  2008/05/03 04:45:24  bisrael
 * Changed to work w/ eclipse.
 *
 * Revision 1.4  2008/05/03 04:30:50  bisrael
 * *** empty log message ***
 *
 * Revision 1.3  2008/05/01 22:51:55  bisrael
 * Uses thread pools to start only a certain number of ssh threads, and
 * waits for all threads to finish before continuing.
 * Changed to use synchronized storage container for ssh thread data.
 * Now sends compiled xml data to web service.
 * Gets all grid data from config file.
 *
 * Revision 1.2  2008/04/30 21:48:54  bisrael
 * *** empty log message ***
 *
 * Revision 1.1  2008/04/30 19:41:02  bisrael
 * Eclipse project for modifying/testing the client before it gets put into the maven project.
 *
 * Revision 1.1  2008/04/22 10:05:10  bisrael
 * Updated the originaly benchmark script to be a web service client and send data to the benchmark web script.
 *
 * Revision 1.1  2008/04/19 07:00:31  bisrael
 * Initial test script that reads in remote hosts from an XML config file, connects to the hosts over SSH, gathers information, and runs benchmarks.
 *
 *
 */
package org.cyberaide.webprojects.benchmarks.benchmarkscript.script;

import java.io.BufferedReader;
import java.io.Console;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Start the threads to spawn out to the remote hosts.
 *
 * @author Brad Israel - bdi8241@cs.rit.edu
 *
 */
public class SSHToHosts {

	/*
	 * XML configuration reader instance
	 */
	private ConfigurationReader config = ConfigurationReader.getInstance();

	/**
	 * Empty default constructor.
	 */
	public SSHToHosts(){}

	/**
	 * Start a thread for each hostname.
	 */
	public void startScript(){
		GridXMLCreator xmlData = new GridXMLCreator();
		
		for( int i = 0; i < config.getNumberOfClusters(); i++){
			//Get login information from config file
			String username = config.getUsername(i);
			File SSHKey = config.getSSHKey(i);
			String clusterName = config.getClusterName(i);

			//Get password for ssh key or system username
			//Use the old eclipse way, will echo the password.
			//Comment out and uncomment Console way before deploying.
//			String password = null;
//			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
//			System.out.print("Enter SSH Key/System Password for " + clusterName + ": ");
//			try {
//				password = br.readLine();
//			} catch (IOException ioe) {
//				System.out.println("IO error trying to read password");
//				System.exit(1);
//			}
			
			//Use the proper Console way (won't echo password).
			//Eclipse can't use this feature yet.
			Console console = System.console();
			if (console == null) {
	            System.err.println("Error trying to read password: No console. Run from command line, not eclipse or other IDE.");
	            System.exit(1);
	        }
			char[] password = console.readPassword("Enter SSH Key/System Password for " + clusterName + ": ");

			
			//Allow a certain number of ssh threads at one time
			ExecutorService executor = Executors.newFixedThreadPool(config.getNumOfConnections(i));

			//Add ssh threads to thread pool
			String[] systemList = config.getSystemList(i);
			for(String hostname : systemList){
				executor.execute(new SSHThread(hostname, username, SSHKey, password.toString(), clusterName, xmlData));
			}

			//Don't allow new executing threads into the pool
			executor.shutdown();
			
			// Wait until all tasks are finished
			while (!executor.isTerminated()) {
			}
			
			//For debugging only
//			System.out.println("ALL SSH CONNECTIONS CLOSED");
			
		}
		
		//Send grid data to web service if there were no errors
		if(!xmlData.didErrorOccur()){
			String response = null;
			try{
				WSClient client = new WSClient(config.getWebService());
				response = client.sendData(config.getGridName(), xmlData.getFinalXml(config.getGridName(), 
						config.getContactName(), config.getContactPhone(), 
						config.getGridLocation()).toString());
			}catch(Exception e){
//				e.printStackTrace();
			}

			if(response != null){
				System.out.println("Data successfully transfered to server. \n" +
						"Thank you for your participation!");
			}else{
				System.out.println("Data failed to transfer to server, check your configuration \n" +
						"and try again.");
			}
		}else{
			System.out.println("An error occurred in one or more of the ssh connections, \n" +
					"please check the console output to find the error.");
		}
		
	}

}
