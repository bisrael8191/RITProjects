/**
 * ConfigurationReader.java
 * 
 * Version:
 * $Id: ConfigurationReader.java,v 1.5 2008/05/03 05:18:04 bisrael Exp $
 * 
 * Revisions:
 * $Log: ConfigurationReader.java,v $
 * Revision 1.5  2008/05/03 05:18:04  bisrael
 * Fixed so that it doesn't send grid information to web service if ssh connection error occurred.
 * Other minor fixes.
 * Commented out debugging output.
 *
 * Revision 1.4  2008/05/03 04:30:50  bisrael
 * *** empty log message ***
 *
 * Revision 1.3  2008/05/01 22:51:55  bisrael
 * Uses thread pools to start only a certain number of ssh threads, and
 * waits for all threads to finish before continuing.
 * Changed to use synchronized storage container for ssh thread data.
 * Now sends compiled xml data to web service.
 * Gets all grid data from config file.
 *
 * Revision 1.2  2008/04/30 21:47:47  bisrael
 * Methods to reflect new configuration.xml file.
 *
 * Revision 1.1  2008/04/30 19:41:02  bisrael
 * Eclipse project for modifying/testing the client before it gets put into the maven project.
 *
 * Revision 1.2  2008/04/22 19:37:41  jludwig
 * bisrael - changed to get more information from configuration file.
 *
 * Revision 1.1  2008/04/22 10:05:10  bisrael
 * Updated the originaly benchmark script to be a web service client and send data to the benchmark web script.
 *
 * Revision 1.1  2008/04/19 07:00:31  bisrael
 * Initial test script that reads in remote hosts from an XML config file, connects to the hosts over SSH, gathers information, and runs benchmarks.
 *
 *
 */
package org.cyberaide.webprojects.benchmarks.benchmarkscript.script;

import java.io.File;
import java.util.Collection;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;

/**
 * Allows other parts of the script to access the configuration
 * file. Uses a singleton design pattern.
 *
 * @author Brad Israel - bdi8241@cs.rit.edu
 *
 */
public class ConfigurationReader extends XMLConfiguration {
	
	/*
	 * Instance variable
	 */
	private static ConfigurationReader instance;
	
	/*
	 * Local configuration file.
	 */
	private static String configFile = "configuration.xml";

	/*
	 * Singleton initialization
	 */
	static {
		instance = new ConfigurationReader(configFile);
	}

	/**
	 * Constructor.
	 *
	 * @param fileName - configuration filename
	 */
	private ConfigurationReader(String filename) {
		init(filename);
	}

	/**
	 * Initialize the class.
	 *
	 * @param fileName - configuration filename
	 */
	private void init(String fileName) {
		setFileName(fileName);
		try {
			load();
		} catch (ConfigurationException configEx) {
			configEx.printStackTrace();
		}
	}

	/**
	 * Singleton access method.
	 *
	 * @return instance
	 */
	public static ConfigurationReader getInstance() {
		return instance;
	}
	
	/**
	 * Get the web service wsdl address.
	 * 
	 * @return WS address
	 */
	public static String getWebService(){
		return instance.getString("Webservice.Address");
	}

	/**
	 * Get grid name.
	 * 
	 * @return grid name
	 */
	public static String getGridName(){
		return instance.getString("Grid.GridInfo.GridName");
	}
	
	/**
	 * Get grid contact name.
	 * 
	 * @return contact name
	 */
	public static String getContactName(){
		return instance.getString("Grid.GridInfo.ContactName");
	}
	
	/**
	 * Get grid contact phone number.
	 * 
	 * @return contact phone number
	 */
	public static String getContactPhone(){
		return instance.getString("Grid.GridInfo.ContactPhone");
	}
	
	/**
	 * Get grid location.
	 * 
	 * @return grid location
	 */
	public static String getGridLocation(){
		return instance.getString("Grid.GridInfo.Location");
	}
	
	/**
	 * Get the ssh username.
	 * 
	 * @param ClusterIndex - xml index for cluster
	 * @return username
	 */
	public static String getUsername(int ClusterIndex){
		return instance.getString("Grid.Clusters.Cluster(" + ClusterIndex + ").ClusterInfo.Username");
	}

	/**
	 * Get the ssh key.
	 * 
	 * @param ClusterIndex - xml index for cluster
	 * @return ssh key
	 */
	public static File getSSHKey(int ClusterIndex){
		File retVal = null;
		String filename = instance.getString("Grid.Clusters.Cluster(" + ClusterIndex + ").ClusterInfo.SSHKey");
		
		if(!filename.equals("")){
			retVal = new File(filename);
		}
		
		return retVal;
	}
	
	/**
	 * Get number of connections to run concurrently.
	 * 
	 * @param ClusterIndex - xml index for cluster
	 * @return number of connection threads
	 */
	public static int getNumOfConnections(int ClusterIndex){
		return instance.getInt("Grid.Clusters.Cluster(" + ClusterIndex + ").ClusterInfo.NumOfConnections");
	}
	
	/**
	 * Get cluster name.
	 * 
	 * @param ClusterIndex - xml index for cluster
	 * @return cluster name
	 */
	public static String getClusterName(int ClusterIndex){
		return instance.getString("Grid.Clusters.Cluster(" + ClusterIndex + ").ClusterName");
	}
	
	/**
	 * Get number of clusters in the xml file.
	 * 
	 * @return number of clusters
	 */
	public static int getNumberOfClusters(){
		int retVal = 0;
		
		//Get host list from config file
		Object clusters = instance.getProperty("Grid.Clusters.Cluster.ClusterName");

		//Check if there's more than one host
		if(clusters instanceof Collection){
			retVal = ((Collection)clusters).size();
		}else if(clusters instanceof String){
			retVal = 1;
		}
		
		return retVal;
	}

	/**
	 * Get the list of remote hosts.
	 * 
	 * @param ClusterIndex - xml index for cluster
	 * @return host list
	 */
	public static String[] getSystemList(int ClusterIndex){
		String[] hostnames = null;
		
		//Get host list from config file
		Object systemList = instance.getProperty("Grid.Clusters.Cluster(" + ClusterIndex + ").SystemList.Hostname");

		//Check if there's more than one host
		if(systemList instanceof Collection){
			hostnames = new String[((Collection)systemList).size()];
			for(int i = 0; i < ((Collection)systemList).size(); i++){
				hostnames[i] = (String)instance.getProperty(
						"Grid.Clusters.Cluster(" + ClusterIndex + ").SystemList.Hostname(" + i + ")");
			}
		}else if(systemList instanceof String){
			hostnames = new String[1];
			hostnames[0] = (String)systemList;
		}
		
		return hostnames;
	}

	/**
	 * Get the list of benchmarks to run.
	 * 
	 * @return benchmark list
	 */
	public static String[] getBenchmarks(){
		String[] benchmarks = null;
		
		//Get the benchmark list from the config file
		Object benchmarksList = instance.getProperty("Grid.Benchmarks.Benchmark.Path");

		//Check if there's more than one benchmark
		if(benchmarksList instanceof Collection){
			benchmarks = new String[((Collection)benchmarksList).size()];
			for(int i = 0; i < ((Collection)benchmarksList).size(); i++){
				benchmarks[i] = (String)instance.getProperty("Grid.Benchmarks.Benchmark(" + i + ").Path");
			}
		}else if(benchmarksList instanceof String){
			benchmarks = new String[1];
			benchmarks[0] = (String)benchmarksList;
		}
		
		return benchmarks;
	}
}
