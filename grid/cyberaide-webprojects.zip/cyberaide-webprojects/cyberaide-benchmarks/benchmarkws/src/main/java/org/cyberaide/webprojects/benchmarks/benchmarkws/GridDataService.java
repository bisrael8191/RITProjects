package org.cyberaide.webprojects.benchmarks.benchmarkws;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class GridDataService {
	
	public String getXML() {
		File data = new File("webapps/benchmarks/GridData.xml");
		
		BufferedReader in = null;
		try {
			in = new BufferedReader(new FileReader(data));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		}
		
		StringBuilder builder = new StringBuilder();
		String line;
		try {
			while ((line = in.readLine()) != null) builder.append(line + "\n");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return builder.toString();
	}

}
