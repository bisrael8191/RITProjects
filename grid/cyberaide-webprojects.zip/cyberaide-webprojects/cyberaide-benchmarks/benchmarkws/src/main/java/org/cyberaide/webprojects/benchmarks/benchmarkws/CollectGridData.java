/**
 * CollectGridData.java
 * 
 * Version:
 * $Id: CollectGridData.java,v 1.7 2008/05/22 03:42:15 jludwig Exp $
 * 
 * Revisions:
 * $Log: CollectGridData.java,v $
 * Revision 1.7  2008/05/22 03:42:15  jludwig
 * GridDataService preserves line-breaks
 * benchmark explorer shows benchmarking results
 *
 * Revision 1.6  2008/05/21 08:28:16  jludwig
 * reorganized and added a new web service to query grid data
 *
 * Revision 1.5  2008/05/20 09:06:00  bisrael
 * Added methods to replace previously submitted data.
 *
 * Revision 1.4  2008/05/06 07:50:35  bisrael
 * Minor changes.
 *
 * Revision 1.3  2008/05/06 07:28:00  bisrael
 * Properly creates or modifies the data file to add new grids.
 * Still needs to check if the grid data already exists and modify it.
 * Index page also displays a table of the different submitted grids.
 *
 * Revision 1.2  2008/05/01 22:52:52  bisrael
 * Changed web service to take in an xml file as a string and output it.
 *
 * Revision 1.1  2008/04/30 19:01:34  bisrael
 * Eclipse project for modifying/testing the benchmark ws, before moving it into the maven project.
 *
 * Revision 1.1  2008/04/22 10:06:00  bisrael
 * First iteration of the benchmark web service.
 *
 *
 */
package org.cyberaide.webprojects.benchmarks.benchmarkws;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Web service that receives and processes data from the benchmark script.
 *
 * @author Brad Israel - bdi8241@cs.rit.edu
 *
 */
public class CollectGridData {

	public String collect(String gridName, String clientXml){
		String cResponse = "failed";

		//TODO: Output to a file that GWT/jsp can access
		try{
			File data = new File("webapps/benchmarks/GridData.xml");
			
			//Xml parsers/builder
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = null;

			//Check if the data file exists
			if(data.exists()){
				//Parse existing document
				doc = builder.parse(data);

				//Get root document
				Element root = doc.getDocumentElement();

				//Remove any previous entries for that grid name
				removeGrid(doc, gridName);

				//Create the new grid element
				Element newGrid = doc.createElement("Grid");

				newGrid.setTextContent(clientXml);
				root.appendChild(newGrid);

			}else{
				//Create the new document
				doc = builder.newDocument();

				//Set the root element to <Grids></Grids>
				Element root = doc.createElement("Grids");
				doc.appendChild(root);

				//Add the incoming data as a grid element
				Element newGrid = doc.createElement("Grid");
				newGrid.setTextContent(clientXml);
				root.appendChild(newGrid);
			}

			//Write the file back to the same filename
			TransformerFactory transfac = TransformerFactory.newInstance();
			Transformer trans = transfac.newTransformer();

			//Create string from xml tree
			StringWriter sw = new StringWriter();
			StreamResult result = new StreamResult(sw);
			DOMSource source = new DOMSource(doc);
			trans.transform(source, result);
			String xmlString = sw.toString();

			//Replace the character codes for < and > in the 
			//xml string
			xmlString = xmlString.replaceAll("&lt;", "<");
			xmlString = xmlString.replaceAll("&gt;", ">");

			//Create file 
			FileWriter fstream = new FileWriter(data);
			BufferedWriter out = new BufferedWriter(fstream);
			out.write(xmlString);
			
			System.out.println("new data!\n" + xmlString);

			//Close the output stream
			out.close();
			cResponse = "sucess";

		}catch (Exception e){//Catch exception if any
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace();
		}

		//Tell the client that everything was sent to the WS
		return cResponse;
	}

	/**
	 * Checks if the submitted grid already exists.
	 * If it does, it overwrites the entry (this will
	 * probably be changed to actually have security
	 * in the next version)
	 * 
	 * @param doc - Parsed xml document
	 * @param gridName - new grid name
	 */
	private void removeGrid(Document doc, String gridName){
		//Get XML root node
		Node root = doc.getDocumentElement();
		
		//Get all "GridName" nodes
		NodeList list = doc.getElementsByTagName("GridName");
		
		//Loop through the existing grids
		for(int i = 0; i < list.getLength(); i++){
			Node node = list.item(i);
			String name = getNodeValue(node);
			
			//If an existing name equals the submitted grid name
			if(name.equals(gridName)){
				System.out.println("Replacing node");
				//Turn node into element
				Element gridElem = (Element)node;
				
				//Remove element's parent's parent from root
				root.removeChild(gridElem.getParentNode().getParentNode());
				
				//Normalize XML document
				doc.normalize();
			}
		}
	}
	
	/**
	 * Get the text of a node.
	 * 
	 * @param node - input node
	 * @return node text
	 */
	private String getNodeValue(Node node) {
		StringBuffer buf = new StringBuffer();
		NodeList children = node.getChildNodes();
		for (int i = 0; i < children.getLength(); i++) {
			Node textChild = children.item(i);
			if (textChild.getNodeType() != Node.TEXT_NODE) {
				System.err.println("Mixed content! Skipping child element: "
						+ textChild.getNodeName());
				continue;
			}
			buf.append(textChild.getNodeValue());
		}
		return buf.toString();
	}
}
