###Cyberaide Web Projects Readme###

##Installation

#Requirements
	Java JDK 5.0
	Maven 2.0.8
	Bash (Any recent version)
	Unix-based OS (Linux, Unix, Mac OSX) to run the server

To install the cyberaide tomcat version and all web projects, first set the JAVA_HOME environment
variable to your system's java path. Then edit the main pom.xml file to change the install path and
server configuration. This defaults to the current user's home directory/cyberaide/cyberaide-webprojects. 
Then run

'mvn clean install' 

to install and deploy the webprojects.

##Uninstalling
To uninstall run 'mvn clean'. NOTE: This will not stop the webserver, this must be done manually
before uninstalling.

##Starting Tomcat
For Unix-based systems run

'./tomcat_admin.sh start'

from inside the maven installation directory. The start/stop scripts can be copied anywhere
you want for easier server control.

##Stopping Tomcat
For Unix-based systems run

'./tomcat_admin.sh stop'

from inside the maven installation directory.

##Restarting Tomcat
For Unix-based systems run

'./tomcat_admin.sh restart'

from inside the maven installation directory.

##Changing the Tomcat configuration
If you need to add your project to the Tomcat homepage, un-tar the 
cyberaide-tomcat_deploy/cyberaide-tomcat6.tar.gz file and edit the 
cyberaide-tomcat6/webapps/ROOT/index.html file to add a line like:

<a href="PROJECT_NAME/index.html">Project Name</a><br>

where PROJECT_NAME is the path in the webapps folder that you are planning to deploy
web services or web pages to. An example of how to deploy a webservice can be found in the
cyberaide-benchmarks/benchmarkws/pom.xml file.

##Adding new projects
To make a new project that gets built during the install, create a directory called 
cyberaide-PROJECT_NAME. Then open the main pom.xml file and add the line:

<module>cyberaide-PROJECT_NAME</module>

This will call the main pom.xml file in your new project directory. In the project's pom.xml,
make a reference to the parent pom.xml by adding the lines:

<parent>
	<artifactId>webprojects</artifactId>
	<groupId>org.cyberaide</groupId>
	<version>1.0-SNAPSHOT</version>
</parent>

This will allow you to get the project properties found in the main pom.xml. Examples of this can
be found in the cyberaide-benchmarks folder. Any project specific settings should go into the 
project's pom.xml file, not the main pom.xml file.

##External libraries that aren't found in a repository
To add external libraries to your java build path, place them in a directory inside the project that
needs them (cyberaide-benchmarks/ExternalLibraries/pom.xml for example), then in the build 
section of the pom.xml file add:

<plugin>
	<artifactId>maven-antrun-plugin</artifactId>
	<executions>
		<execution>
			<id>install libraries</id>
			<phase>compile</phase>
			<configuration>
				<tasks>
					<echo message="Installing Trilead SSH Library"/>
					<exec dir="${basedir}/ExternalLibraries" executable="mvn">
						<arg value="install:install-file"/>
						<arg value="-Dfile=trilead-ssh2.jar"/>
						<arg value="-DgroupId=com.trilead"/>
						<arg value="-DartifactId=ssh2"/>
						<arg value="-Dversion=213"/>
						<arg value="-Dpackaging=jar"/>
					</exec>
				</tasks>
			</configuration>
			<goals>
				<goal>run</goal>
			</goals>
		</execution>
	</executions>
</plugin>

Change the Trilead SSH specific things, to your libraries name, jar, version, etc. This will run
the maven command to add the jar to the local repository. In the project it can then be used
like:

<dependency>
	<groupId>com.trilead</groupId>
	<artifactId>ssh2</artifactId>
	<version>213</version>
</dependency>


##Known Bugs
-The GWT (Google Web Toolkit) code that generated a map and nicer table on the website is not currently available to be deployed. This will be fixed soon, but deploying GWT has other issues, such as requiring the person who wants to install the Cyberaide Tomcat server to apply for a license that matches their domain. If a license is not found or installed incorrectly, the web interface will only work for users in the localhost domain, which means that people that don't have shell access to their computer will not be able to view the data display. For now, we are just using a straight jsp table display, which isn't fancy, but works well. The test code that we demo'ed in class can be found in the svn/projects/Architecture folder in zip format. 

-Benchmark script cannot use the newer Console IO package properly. This has the effect that when the user types their password into the terminal, it is echoed back to them. Once OSX gets native Java 6.0 support, this code can be uncommented in the webprojects.benchmarks.benchmarkscript.script.SSHToHosts class. This change is documented in the code.

-Our paper lays out many more future improvements that we would like to see included into the code.

###